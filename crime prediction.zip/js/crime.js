function displayCrimeDetails() {
    var state = document.getElementById('state').value;
    var crimeDetailsDiv = document.getElementById('crimeDetails');

    if (state === 'tamilnadu') {
        crimeDetailsDiv.innerHTML = `
            <h2>Tamil Nadu</h2>
            <img src="murder_image.jpg" alt="Murder">
            <p>Total number of crimes: 500</p>
        `;
    } else if (state === 'kerala') {
        crimeDetailsDiv.innerHTML = `
            <h2>Kerala</h2>
            <img src="theft_image.jpg" alt="Theft">
            <p>Total number of crimes: 300</p>
        `;
    } else if (state === 'delhi') {
        crimeDetailsDiv.innerHTML = `
            <h2>Delhi</h2>
            <img src="crime_image.jpg" alt="Crime">
            <p>Total number of crimes: 700</p>
        `;
    } else if (state === 'maharashtra') {
        crimeDetailsDiv.innerHTML = `
            <h2>Maharashtra</h2>
            <img src="robbery_image.jpg" alt="Robbery">
            <p>Total number of crimes: 400</p>
        
`;
}else {
   crimeDetailsDiv.innerHTML = '';
 }
}
